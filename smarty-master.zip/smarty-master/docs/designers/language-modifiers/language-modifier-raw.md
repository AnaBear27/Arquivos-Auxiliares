# raw

Prevents variable escaping when [auto-escaping](../../api/configuring.md#enabling-auto-escaping) is activated.

## Basic usage
```smarty
{$myVar|raw}
```
