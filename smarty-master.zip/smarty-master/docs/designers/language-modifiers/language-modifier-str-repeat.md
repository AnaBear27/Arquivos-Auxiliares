# str_repeat

Repeats the given value n times.

## Basic usage
```smarty
{"hi"|str_repeat:2} # renders: hihi
```

## Parameters

| Parameter | Type | Required | Description           |
|-----------|------|----------|-----------------------|
| 1         | int  | yes      | number of repetitions |
